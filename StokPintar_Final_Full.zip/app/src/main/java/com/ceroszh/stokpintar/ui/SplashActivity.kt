package com.ceroszh.stokpintar.ui
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
class SplashActivity: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(R.style.Theme_StokPintar_Splash)
        super.onCreate(savedInstanceState)
        lifecycleScope.launch { delay(1000L); startActivity(Intent(this@SplashActivity, MainActivity::class.java)); finish() }
    }
}
