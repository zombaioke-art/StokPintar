rootProject.name = "StokPintar"
include(":app")
