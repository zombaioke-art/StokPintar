package com.ceroszh.stokpintar
import android.app.Application
import com.google.android.gms.ads.MobileAds
class StokPintarApp : Application() {
    override fun onCreate() {
        super.onCreate()
        MobileAds.initialize(this) { }
    }
}
